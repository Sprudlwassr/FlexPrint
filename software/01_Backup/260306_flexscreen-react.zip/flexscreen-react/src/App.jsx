import { useState } from 'react'
//import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'; // Um zwischen verschieden HTML-Inhalten im Body zu wechseln
//import Dashboard from './pages/Dashboard';
//import Jobs from './pages/Jobs';

// Das sind Platzhalter für deine späteren Seiten
//const Dashboard = () => <div className="menuBody">Körper: Dashboard Inhalt</div>;
//const Job = () => <div className="menuBody">Körper: Job Liste</div>;
//const System = () => <div className="menuBody">Körper: Systemeinstellungen</div>;

function App() {
  //const [count, setCount] = useState(0)
  return (
    <div className = "main">
        <div className = "header">
            <div className = "headerLeft">
                <button id="btnBack">Back</button>
            </div>
            <div className="headerCenter">
                Flexprint
            </div>
            <div className = "headerRight">
                Connected
            </div>
        </div>
        <div className = "menu">
            <div className = "menuBody">
                Körper
            </div>
            <div className = "menuFooter">
                <div className="dashboard">
                    <button id="btnDashboard">Dashboard</button>
                </div>
                <div className="job">
                    <button id="btnJob">Job</button>
                </div>
                <div className="system">
                    <button id="btnSystem">System</button>
                </div>
            </div>
        </div>
    </div>
  );
}

export default App
